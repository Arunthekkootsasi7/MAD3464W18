/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Generics;

/**
 *
 * @author macstudent
 */
public class Generics {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Box<Integer> integerBox = new Box<Integer>();
            Box<String> StringBox = new Box<String>();
            integerBox.add(new Integer(10));
            StringBox.add(new String("Hello World"));
            System.out.printf("Integer Value :%d\n\n", integerBox.get());
               System.out.printf("String Value :%d\n\n", StringBox.get());  
    }
    
}
 class Box<T> {
     private T t;
     public void add(T t) 
     {
         this.t = t;
                 
     }
     public T get() {
         return t;
     }
     
 }