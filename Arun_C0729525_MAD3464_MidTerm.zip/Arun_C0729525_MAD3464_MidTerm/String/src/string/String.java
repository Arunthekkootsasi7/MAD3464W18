/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author macstudent
 */
public class String {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Encryption1 encryption1 = new Encryption1();
encryption1.encryption1();
       // Encryption2 encryption2 = new Encryption2();
       // encryption2.reverseString();

}
}